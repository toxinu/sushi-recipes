#!/usr/bin/env python
# coding: utf-8
import os

from {{ app|lower }}.logger import stream_logger